void push(char x);
char pop();